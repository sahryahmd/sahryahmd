
package model;

public class layanan {
    
    
    private String id_layanan;
    private String nm_layanan;
    private String jenis;
    private String harga;

    public layanan() {}

    public layanan(String id_layanan, String nm_layanan, String jenis, String harga) {
        this.id_layanan = id_layanan;
        this.nm_layanan = nm_layanan;
        this.jenis = jenis;
        this.harga = harga;
    }

    public String getId_layanan() {
        return id_layanan;
    }

    public void setId_layanan(String id_layanan) {
        this.id_layanan = id_layanan;
    }

    public String getNm_layanan() {
        return nm_layanan;
    }

    public void setNm_layanan(String nm_layanan) {
        this.nm_layanan = nm_layanan;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }
    
    
}
