
package model;


public class pelanggan {
    private String id_plgn;
    private String nm_plgn;
    private String almt;
    private String telp;
    private String no_hp;
    private String tgl;
    private String npwp;
    private String ket;

    public pelanggan() {}

    
    
    public pelanggan(String id_plgn, String nm_plgn, String almt, String telp, String no_hp, String tgl, String npwp, String ket) {
        this.id_plgn = id_plgn;
        this.nm_plgn = nm_plgn;
        this.almt = almt;
        this.telp = telp;
        this.no_hp = no_hp;
        this.tgl = tgl;
        this.npwp = npwp;
        this.ket = ket;
    }

    public String getId_plgn() {
        return id_plgn;
    }

    public void setId_plgn(String id_plgn) {
        this.id_plgn = id_plgn;
    }

    public String getNm_plgn() {
        return nm_plgn;
    }

    public void setNm_plgn(String nm_plgn) {
        this.nm_plgn = nm_plgn;
    }

    public String getAlmt() {
        return almt;
    }

    public void setAlmt(String almt) {
        this.almt = almt;
    }

    public String getTelp() {
        return telp;
    }

    public void setTelp(String telp) {
        this.telp = telp;
    }

    public String getNo_hp() {
        return no_hp;
    }

    public void setNo_hp(String no_hp) {
        this.no_hp = no_hp;
    }

    public String getTgl() {
        return tgl;
    }

    public void setTgl(String tgl) {
        this.tgl = tgl;
    }

    public String getNpwp() {
        return npwp;
    }

    public void setNpwp(String npwp) {
        this.npwp = npwp;
    }

    public String getKet() {
        return ket;
    }

    public void setKet(String ket) {
        this.ket = ket;
    }

    
}
