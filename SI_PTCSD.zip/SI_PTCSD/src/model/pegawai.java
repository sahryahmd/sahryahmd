/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author This
 */
public class pegawai {
    private String id_pegawai;
    private String nm_pegawai;
    private String jabatan;
    private String username;
    private String password;
    private String auth;
    private byte [] pic;

    public pegawai() {}
    
    

    public pegawai(String id_pegawai, String nm_pegawai, String jabatan, String username, String password, String auth, byte[] pic) {
        this.id_pegawai = id_pegawai;
        this.nm_pegawai = nm_pegawai;
        this.jabatan = jabatan;
        this.username = username;
        this.password = password;
        this.auth = auth;
        this.pic = pic;
    }

    public String getId_pegawai() {
        return id_pegawai;
    }

    public void setId_pegawai(String id_pegawai) {
        this.id_pegawai = id_pegawai;
    }

    public String getNm_pegawai() {
        return nm_pegawai;
    }

    public void setNm_pegawai(String nm_pegawai) {
        this.nm_pegawai = nm_pegawai;
    }

    public String getJabatan() {
        return jabatan;
    }

    public void setJabatan(String jabatan) {
        this.jabatan = jabatan;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAuth() {
        return auth;
    }

    public void setAuth(String auth) {
        this.auth = auth;
    }

    public byte[] getPic() {
        return pic;
    }

    public void setPic(byte[] pic) {
        this.pic = pic;
    }
    
    
}
