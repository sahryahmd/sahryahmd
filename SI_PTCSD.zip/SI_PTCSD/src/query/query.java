
package query;

import config.myConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.layanan;
import model.pegawai;
import model.pelanggan;


public class query {
    
    public ArrayList<pegawai>pegawaiList(){
        
        ArrayList<pegawai> plist = new ArrayList<pegawai>();
        Connection con = myConnection.getConnection();
        Statement st;
        ResultSet rs;
       
        try {
        st = con.createStatement();
        rs = st.executeQuery("SELECT `id_pegawai`, `nm_pegawai`, `jbtn`, `username`, `password`, `auth`, `pic` FROM `tb_pegawai`");
        
        while(rs.next()){
            pegawai p = new pegawai(rs.getString("id_pegawai"),
                                    rs.getString("nm_pegawai"),
                                    rs.getString("jbtn"),
                                    rs.getString("username"),
                                    rs.getString("password"),
                                    rs.getString("auth"),
                                    rs.getBytes("pic"));
            plist.add(p);
        }
           
        } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return plist;
        
    }
    
    public void inputPegawai(pegawai peg){
        
        try {
            Connection con = myConnection.getConnection();
            PreparedStatement ps;
            
            ps = con.prepareStatement("INSERT INTO `tb_pegawai`(`id_pegawai`, `nm_pegawai`, `jbtn`, `username`, `password`, `auth`, `pic`) VALUES (?,?,?,?,?,?,?)");
            ps.setString(1, peg.getId_pegawai());
            ps.setString(2, peg.getNm_pegawai());
            ps.setString(3, peg.getJabatan());
            ps.setString(4, peg.getUsername());
            ps.setString(5, peg.getPassword());
            ps.setString(6, peg.getAuth());
            ps.setBytes(7, peg.getPic());
            
              if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
              
                
            }else{
                JOptionPane.showMessageDialog(null, "Data Gagal Disimpan, Cek Kembali Data yang Anda Masukkan");
              
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
     public void hapusPegawai (String pg){
        
        Connection con = myConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = con.prepareStatement("DELETE FROM `tb_pegawai` WHERE `id_pegawai` = ?");
            ps.setString(1, pg);
             if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Data Berhasil di Hapus");

            }else{
                JOptionPane.showMessageDialog(null, "Data Gagal Dihapus, Cek Kembali Datanya");
              
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
     public void ubahPegawai (pegawai p, boolean withImage){

          
            Connection con = myConnection.getConnection();
            PreparedStatement ps;
            String updateQuery = "";            
            if(withImage == true)// jika user ingin update dengan gambar
            {
                updateQuery = "UPDATE `tb_pegawai` SET `nm_pegawai`= ? ,`jbtn`= ? ,`username`= ? ,`password`= ? ,`auth`= ? ,`pic`= ? WHERE `id_pegawai`= ?";
     
                try {
            
            ps = con.prepareStatement(updateQuery);
            ps.setString(1, p.getNm_pegawai());
            ps.setString(2, p.getJabatan());
            ps.setString(3, p.getUsername());
            ps.setString(4, p.getPassword());
            ps.setString(7, p.getId_pegawai());
            ps.setString(5, p.getAuth());
            ps.setBytes(6, p.getPic());
            
             if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Update");
              
                
            }else{
                JOptionPane.showMessageDialog(null, "Fail");
              
            }
             
               } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        }
            }
            else{ // the user want to keep image
              updateQuery = "UPDATE `tb_pegawai` SET `nm_pegawai`= ? ,`jbtn`= ? ,`username`= ? ,`password`= ? ,`auth`= ?  WHERE `id_pegawai`= ?";
     
                try {
            
            ps = con.prepareStatement(updateQuery);
             ps.setString(1, p.getNm_pegawai());
            ps.setString(2, p.getJabatan());
            ps.setString(3, p.getUsername());
            ps.setString(4, p.getPassword());
            ps.setString(6, p.getId_pegawai());
            ps.setString(5, p.getAuth());
            
           
            
             if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Updated");
              
                
            }else{
                JOptionPane.showMessageDialog(null, "Fail");
              
            }
             
               } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        }

            }
    }
     
     
     public ArrayList<pelanggan>pelangganList(){
        
        ArrayList<pelanggan> plist = new ArrayList<pelanggan>();
        Connection con = myConnection.getConnection();
        Statement st;
        ResultSet rs;
       
        try {
        st = con.createStatement();
        rs = st.executeQuery("SELECT `id_plgn`, `nm_plgn`, `almt`, `telp`, `no_hp`, `tgl`, `npwp`, `ket` FROM `tb_pelanggan`");
        
        while(rs.next()){
            pelanggan p = new pelanggan(rs.getString("id_plgn"),
                                    rs.getString("nm_plgn"),
                                    rs.getString("almt"),
                                    rs.getString("telp"),
                                    rs.getString("no_hp"),
                                    rs.getString("tgl"),
                                    rs.getString("npwp"),
                                    rs.getString("ket"));
            plist.add(p);
        }
           
        } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return plist;
        
    }
     
     public void inputpelanggan (pelanggan pel){
         
         Connection con = myConnection.getConnection();
         PreparedStatement ps;
        try {
            ps = con.prepareStatement("INSERT INTO `tb_pelanggan`(`id_plgn`, `nm_plgn`, `almt`, `telp`, `no_hp`, `tgl`, `npwp`, `ket`) VALUES (?,?,?,?,?,?,?,?)");
            ps.setString(1, pel.getId_plgn());
            ps.setString(2, pel.getNm_plgn());
            ps.setString(3, pel.getAlmt());
            ps.setString(4, pel.getTelp());
            ps.setString(5, pel.getNo_hp());
            ps.setString(6, pel.getTgl());
            ps.setString(7, pel.getNpwp());
            ps.setString(8, pel.getKet());
            
            if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
              
                
            }else{
                JOptionPane.showMessageDialog(null, "Data Gagal Disimpan, Cek Kembali Data yang Anda Masukkan");
              
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
     
     public void hapusPelanggan (String pl){
        
        Connection con = myConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = con.prepareStatement("DELETE FROM `tb_pelanggan` WHERE `id_plgn` = ?");
            ps.setString(1, pl);
             if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Data Berhasil di Hapus");

            }else{
                JOptionPane.showMessageDialog(null, "Data Gagal Dihapus, Cek Kembali Datanya");
              
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
     
     public void ubahPelanggan (pelanggan pl){
         Connection con = myConnection.getConnection();
         PreparedStatement ps;
         String updateQuery = "";
         
          updateQuery = "UPDATE `tb_pelanggan` SET `nm_plgn`= ? ,`almt`= ? ,`telp`= ? ,`no_hp`= ? ,`tgl`= ? ,`npwp`= ? ,`ket`= ? WHERE `id_plgn` = ?";
         
        try {
            ps = con.prepareStatement(updateQuery);
            
            ps.setString(1, pl.getNm_plgn());
            ps.setString(2, pl.getAlmt());
            ps.setString(3, pl.getTelp());
            ps.setString(4, pl.getNo_hp());
            ps.setString(5, pl.getTgl());
            ps.setString(6, pl.getNpwp());
            ps.setString(7, pl.getKet());
            ps.setString(8, pl.getId_plgn());
            
              
             if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Data Berhasil di Ubah");
              
                
            }else{
                JOptionPane.showMessageDialog(null, "Data Gagal Diubah Cek Kembali!!");
              
            }
        } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
    public ArrayList<layanan>layananList(){
        
        ArrayList<layanan> llist = new ArrayList<layanan>();
        Connection con = myConnection.getConnection();
        Statement st;
        ResultSet rs;
       
        try {
        st = con.createStatement();
        rs = st.executeQuery("SELECT `id_layanan`, `nm_layanan`, `jenis`, `harga` FROM `tb_layanan`");
        
        while(rs.next()){
            layanan l = new layanan(rs.getString("id_layanan"),
                                    rs.getString("nm_layanan"),
                                    rs.getString("jenis"),
                                    rs.getString("harga"));
                                    
            llist.add(l);
        }
           
        } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return llist;
    }
    
    public void inputlayanan (layanan ly){
         
         Connection con = myConnection.getConnection();
         PreparedStatement ps;
        try {
            ps = con.prepareStatement("INSERT INTO `tb_layanan`(`id_layanan`, `nm_layanan`, `jenis`, `harga`) VALUES (?,?,?,?)");
            ps.setString(1, ly.getId_layanan());
            ps.setString(2, ly.getNm_layanan());
            ps.setString(3, ly.getJenis());
            ps.setString(4, ly.getHarga());
            
            if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");

            }else{
                JOptionPane.showMessageDialog(null, "Data Gagal Disimpan, Cek Kembali Data yang Anda Masukkan");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
    
     public void hapusLayanan (String ly){
        
        Connection con = myConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = con.prepareStatement("DELETE FROM `tb_layanan` WHERE `id_layanan` = ?");
            ps.setString(1, ly);
             if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Data Berhasil di Hapus");

            }else{
                JOptionPane.showMessageDialog(null, "Data Gagal Dihapus, Cek Kembali Datanya");
              
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
     
     public void ubahLayanan (layanan ly){
         Connection con = myConnection.getConnection();
         PreparedStatement ps;
         String updateQuery = "";
         
          updateQuery = "UPDATE `tb_layanan` SET `nm_layanan`= ? ,`jenis`= ? ,`harga`= ? WHERE `id_layanan`= ?";
         
        try {
            ps = con.prepareStatement(updateQuery);
            
            ps.setString(4, ly.getId_layanan());
            ps.setString(1, ly.getNm_layanan());
            ps.setString(2, ly.getJenis());
            ps.setString(3, ly.getHarga());
           
            
              
             if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Data Berhasil di Ubah");
              
                
            }else{
                JOptionPane.showMessageDialog(null, "Data Gagal Diubah Cek Kembali!!");
              
            }
        } catch (SQLException ex) {
            Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
    
}
