
package config;

import javax.swing.Icon;
import javax.swing.table.AbstractTableModel;

public class tablemodel extends AbstractTableModel {
    private String [] kolom;
    private Object[][] baris;
    
    public tablemodel (){}
    
    public tablemodel(Object[][]data, String[] namaKolom){
        this.kolom = namaKolom;
        this.baris = data;
    }
    

    @Override
   public Class getColumnClass(int col)
    {
        //the index od the image column is 8
        if(col == 9){ return Icon.class;}
        else{
            return getValueAt(0, col).getClass();
        }
    }  
    
    @Override
    public int getRowCount() {
       return this.baris.length;
    }

    @Override
    public int getColumnCount() {
        return this.kolom.length;
    }

    @Override
    public Object getValueAt(int barisIndex, int kolomIndex) {
    return this.baris[barisIndex][kolomIndex];
    }
    
     @Override
    public String getColumnName(int kol){
        return this.kolom[kol];
    }
}
    
